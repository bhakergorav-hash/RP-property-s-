package com.rppropertys.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    int green = Color.rgb(27,94,32);

    TextView tv(String text, float size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(Color.DKGRAY);
        v.setPadding(20, 16, 20, 16);
        return v;
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 28, 20, 28);
        scroll.addView(root);

        TextView title = tv("RP Propertys", 30);
        title.setTextColor(green);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView sub = tv("Nagaur • Property Buying & Selling", 17);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        root.addView(tv("Available Properties", 22));

        addProperty("🏠 30 × 50 Plot — Nagaur City",
                "Near Nakaas Gate • Approx. 500 m from Railway Station • Prime Location");

        addProperty("🏡 25 × 50 Plots — Nagaur City",
                "4 plots available • Prime location inside Nagaur City");

        addProperty("🌾 73 Bigha Land — Nagaur District",
                "Main/pakki road • Road access on both sides");

        addProperty("🌳 1 Bigha Land — Ring Road",
                "Jodhpur side / bypass • Nagaur");

        root.addView(tv("Contact RP Propertys", 22));
        Button insta = btn("Open Instagram @rp_propertys_nagaur");
        insta.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.instagram.com/rp_propertys_nagaur/")));
            } catch(Exception e) {}
        });
        root.addView(insta);

        TextView footer = tv("Ramprakash Mehariya • Nagaur", 15);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);

        setContentView(scroll);
    }

    void addProperty(String name, String details) {
        TextView n = tv(name, 19);
        n.setTextColor(Color.BLACK);
        root.addView(n);
        root.addView(tv(details, 15));
        Button enquiry = btn("Enquire on WhatsApp");
        enquiry.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/919024398755?text=Hello%20RP%20Propertys,%20I%20am%20interested%20in%20a%20property."));
            startActivity(i);
        });
        root.addView(enquiry);
        root.addView(tv("────────────────────────", 12));
    }
}
