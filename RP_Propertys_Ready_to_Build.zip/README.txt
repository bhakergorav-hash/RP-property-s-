RP PROPERTYs — READY-TO-BUILD ANDROID PROJECT

This is an Android Studio/Gradle project for the RP Propertys app.

Features:
- RP Propertys branding
- Nagaur property listings
- 30x50 plot near Nakaas Gate
- 25x50 plots
- 73 bigha land listing
- 1 bigha Ring Road listing
- Instagram button
- WhatsApp enquiry button

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync/download dependencies.
3. Select Build > Build APK(s).
4. The debug APK will be generated under:
   app/build/outputs/apk/debug/app-debug.apk

Note: This ZIP is the ready-to-build project, not the compiled APK itself.
